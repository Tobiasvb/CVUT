## Copyright (C) 2016 Tobias
## 
## This program is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {Function File} {@var{retval} =} tttest (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: Tobias <tobias@tobias-K52JK>
## Created: 2016-03-04

x = 1:10;
y = x.^2;

parabol = plot(x,y);
ftsize = 16;
xlabel('x','Fontsize',ftsize);ylabel('y','Fontsize',ftsize);
title('parabola','Fontsize',ftsize);
set(parabol,'LineWidth',2);
set(gca,'FontSize',fsize);
set(gcf,'PaperPosition',[0.5 0.5 21.5 18.5];
set(gcf,'PaperSize',[18 14]);
saveas(parabol,'parabolprint.pdf');


